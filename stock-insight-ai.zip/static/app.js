const $=s=>document.querySelector(s);
const money=v=>v==null?'—':new Intl.NumberFormat('en-IN',{maximumFractionDigits:2}).format(v);
const fmt=(v,c)=>v==null?'—':`${c||''} ${money(v)}`.trim();
const exact=v=>v==null?'Not available':Number(v).toFixed(2);
const crore=v=>v==null?'Not reported':`₹${money(v/10000000)} Cr`;
const metric=(label,value)=>`<div class="metric"><span>${label}</span><strong>${value??'—'}</strong></div>`;
const list=items=>items.map(x=>`<li>${x}</li>`).join('');

$('#search').addEventListener('submit',async e=>{e.preventDefault();const ticker=$('#ticker').value.trim(),error=$('#error'),load=$('#loading'),result=$('#result');error.style.display='none';result.hidden=true;load.hidden=false;try{const r=await fetch('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ticker})}),d=await r.json();if(!r.ok)throw Error(d.detail||'Unable to analyse this ticker.');render(d)}catch(err){error.textContent=err.message;error.style.display='block'}finally{load.hidden=true}});

function render(d){
 const f=d.facts,report=d.report,x=d.financials,c=f.currency;
 const panels=[
  ['Income statement',report.income_statement,[['Revenue growth',x.revenue_change_pct==null?'Not reported':`${x.revenue_change_pct>0?'+':''}${x.revenue_change_pct}% YoY`],['Net income',crore(x.net_income)],['Interest expense',crore(x.interest_expense)]]],
  ['Balance sheet',report.balance_sheet,[['Total debt',crore(x.total_debt)],['Shareholders’ equity',crore(x.equity)],['Short-term debt',crore(x.short_term_debt)]]],
  ['Cash flow statement',report.cash_flow,[['Operating cash flow',crore(x.operating_cash_flow)],['Capital expenditure',crore(x.capex)],['Free cash flow',crore(x.free_cash_flow)]]]
 ];
 $('#symbol').textContent=f.ticker;$('#company').textContent=f.company;$('#asof').textContent=`Market data checked ${f.as_of}`;$('#currency').textContent=c;$('#price').textContent=money(f.price);
 $('#metrics').innerHTML=[metric('Price / Earnings',money(f.pe)),metric('Debt / Equity',exact(f.debt_equity)),metric('Price / Book',money(f.price_book)),metric('Return on Equity',f.roe==null?'Not available':`${exact(f.roe)}%`),metric('Gross margin',f.gross_margin==null?'—':`${money(f.gross_margin)}%`)].join('');
 $('#fair').textContent=f.fair_value==null?'Not available':fmt(f.fair_value,c);$('#fairNote').textContent=f.fair_value==null?'Graham fair value requires positive annual EPS and book value per share.':`Graham value based on EPS ${fmt(f.eps,c)} and book value ${fmt(f.book_value,c)} per share.`;
 $('#health').innerHTML=[['Liquidity ratio',exact(x.liquidity_ratio)],['Industry P/E',exact(x.industry_pe)],['Interest coverage',x.interest_coverage==null?'Not available':`${exact(x.interest_coverage)}x`]].map(([label,value])=>`<div><small>${label}</small><b>${value}</b></div>`).join('');
 $('#news').innerHTML=list(report.news.slice(0,5));$('#statements').innerHTML=panels.map(([title,items,figures])=>`<article class="statement"><div class="label">FINANCIAL STATEMENTS</div><h3>${title}</h3><div class="figures"><span>All figures in ₹ Cr</span>${figures.map(([label,value])=>`<div><small>${label}</small><b>${value}</b></div>`).join('')}</div><ul>${items.map(i=>`<li>${i}</li>`).join('')}</ul></article>`).join('');$('#disclaimer').textContent=report.disclaimer;$('#result').hidden=false;$('#result').scrollIntoView({behavior:'smooth',block:'start'});
}
