STOCK INSIGHT AI
================

What it does
------------
Enter a ticker. NSE and BSE formats are accepted: RELIANCE or NSE:RELIANCE (NSE), and RELIANCE.BO or BSE:RELIANCE (BSE). The app obtains market and financial-statement data, estimates Graham fair value (sqrt(22.5 × EPS × book value)), searches current web-news sources, and uses a LangGraph workflow with GPT-4o-mini to create a concise research review.

Install
-------
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create an environment:
   python -m venv .venv
4. Activate it:
   Windows: .venv\Scripts\activate
   macOS/Linux: source .venv/bin/activate
5. Install packages:
   pip install -r requirements.txt
6. Open main.py and replace PASTE_YOUR_OPENAI_API_KEY_HERE with your OpenAI API key.
   Alternatively set OPENAI_API_KEY in your environment.
7. Run:
   uvicorn main:app --reload
8. Visit http://127.0.0.1:8000 in your browser.

Notes
-----
- gpt-4o-mini is explicitly configured in main.py.
- Tickers without an exchange suffix are tried on NSE (.NS), then BSE (.BO). Use NSE:SYMBOL or BSE:SYMBOL when a symbol exists on both exchanges and you want a specific listing.
- News is obtained through a general Google News RSS web-search query. Search results and market-data coverage can change; the app does not bypass access controls.
- Data can be delayed or incomplete. This is an educational research tool, not investment advice.
