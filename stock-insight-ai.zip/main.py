"""Stock Insight AI — FastAPI + LangChain/LangGraph application.

Paste your key in OPENAI_API_KEY below (or set it as an environment variable).
"""
import json
import math
import os
import re
import time
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from typing import Any, TypedDict
from urllib.parse import quote
from xml.etree import ElementTree as ET

import requests
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph
from pydantic import BaseModel, Field

# ===================== PASTE YOUR OPENAI API KEY HERE =====================
OPENAI_API_KEY = "PASTE_YOUR_OPENAI_API_KEY_HERE"
# ===========================================================================

app = FastAPI(title="Stock Insight AI")
app.mount("/static", StaticFiles(directory="static"), name="static")


class TickerRequest(BaseModel):
    ticker: str = Field(..., min_length=1, max_length=20)


class ResearchState(TypedDict, total=False):
    ticker: str
    facts: dict[str, Any]
    financials: dict[str, Any]
    web_news: list[str]
    ai_report: dict[str, Any]


def n(v: Any) -> float | None:
    try:
        value = float(v)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def ratio(v: Any, digits: int = 2) -> float | None:
    value = n(v)
    return round(value, digits) if value is not None else None


def crore(v: Any) -> str:
    """Format rupee statement figures in Indian crores (1 crore = 10,000,000)."""
    value = n(v)
    return f"₹{value / 10_000_000:,.2f} Cr" if value is not None else "Not reported"


def first_value(frame: Any, labels: list[str]) -> float | None:
    if frame is None or getattr(frame, "empty", True):
        return None
    for label in labels:
        if label in frame.index:
            series = frame.loc[label].dropna()
            if not series.empty:
                return n(series.iloc[0])
    return None


def prior_value(frame: Any, labels: list[str]) -> float | None:
    if frame is None or getattr(frame, "empty", True):
        return None
    for label in labels:
        if label in frame.index:
            series = frame.loc[label].dropna()
            if len(series) > 1:
                return n(series.iloc[1])
    return None


def percent_change(current: float | None, previous: float | None) -> float | None:
    if current is None or previous in (None, 0):
        return None
    return round((current - previous) / abs(previous) * 100, 1)


def web_search_headlines(ticker: str, company: str) -> list[str]:
    """Use a general web-news search feed; failures never block analysis."""
    query = f'"{company}" stock OR earnings OR analyst'
    try:
        xml = requests.get(
            "https://news.google.com/rss/search",
            params={"q": query, "hl": "en-IN", "gl": "IN", "ceid": "IN:en"},
            headers={"User-Agent": "Mozilla/5.0"}, timeout=10,
        ).text
        root = ET.fromstring(xml)
        cutoff = datetime.now(timezone.utc) - timedelta(days=183)
        found: list[str] = []
        for item in root.findall("./channel/item"):
            text = (item.findtext("title") or "").strip()
            date = item.findtext("pubDate")
            try:
                published = parsedate_to_datetime(date) if date else cutoff
            except (TypeError, ValueError):
                published = cutoff
            if published.tzinfo is None:
                published = published.replace(tzinfo=timezone.utc)
            if published < cutoff:
                continue
            if len(text) > 25 and text not in found:
                found.append(text)
        return found[:8]
    except (requests.RequestException, ET.ParseError):
        return []


def exchange_candidates(user_ticker: str) -> list[str]:
    """Normalize common NSE/BSE entry formats into Yahoo Finance symbols.

    Examples: NSE:RELIANCE, RELIANCE.NS, BSE:RELIANCE, and RELIANCE.BO
    all resolve without the user knowing the Yahoo Finance exchange suffix.
    """
    value = user_ticker.strip().upper().replace(" ", "")
    value = value.replace("NSE-", "NSE:").replace("BSE-", "BSE:")
    # HDFC Ltd merged into HDFC Bank. Retain the widely used legacy search term.
    if value in {"HDFC", "NSE:HDFC", "BSE:HDFC"}:
        value = value.replace("HDFC", "HDFCBANK")
    if value.startswith("NSE:"):
        return [f"{value[4:]}.NS"]
    if value.startswith("BSE:"):
        return [f"{value[4:]}.BO"]
    if value.endswith(".NS") or value.endswith(".BO"):
        return [value]
    # An unqualified Indian equity symbol is checked on NSE first, then BSE.
    return [f"{value}.NS", f"{value}.BO", value]


YAHOO_HEADERS = {"User-Agent": "Mozilla/5.0 (StockInsightAI/1.0)", "Accept": "application/json"}
FUNDAMENTAL_TYPES = [
    "annualTotalRevenue", "annualOperatingExpense", "annualNetIncome", "annualInterestExpense",
    "annualEBIT", "annualGrossProfit", "annualTotalDebt", "annualStockholdersEquity",
    "annualAccountsReceivable", "annualInventory", "annualCurrentDebt", "annualOperatingCashFlow",
    "annualCapitalExpenditure", "annualCashDividendsPaid", "annualDilutedEPS",
    "annualDilutedAverageShares", "annualCashCashEquivalentsAndShortTermInvestments",
    "annualCurrentAssets", "annualCurrentLiabilities",
]


def yahoo_chart(symbol: str) -> dict[str, Any] | None:
    """Fetch price directly; avoids yfinance's crumb/cookie validation path."""
    try:
        response = requests.get(
            f"https://query1.finance.yahoo.com/v8/finance/chart/{quote(symbol)}",
            params={"range": "5d", "interval": "1d"}, headers=YAHOO_HEADERS, timeout=12,
        )
        payload = response.json()
        result = (payload.get("chart", {}).get("result") or [None])[0]
        if not result:
            return None
        closes = result.get("indicators", {}).get("quote", [{}])[0].get("close", [])
        price = next((n(v) for v in reversed(closes) if n(v) is not None), None)
        if price is None:
            price = n(result.get("meta", {}).get("regularMarketPrice"))
        return {"meta": result.get("meta", {}), "price": price} if price is not None else None
    except (requests.RequestException, ValueError, TypeError):
        return None


def yahoo_fundamentals(symbol: str) -> dict[str, list[float]]:
    """Retrieve annual statement lines from Yahoo's public time-series API."""
    try:
        response = requests.get(
            f"https://query1.finance.yahoo.com/ws/fundamentals-timeseries/v1/finance/timeseries/{quote(symbol)}",
            params={"symbol": symbol, "type": ",".join(FUNDAMENTAL_TYPES), "period1": 1609459200, "period2": int(time.time()) + 86400},
            headers=YAHOO_HEADERS, timeout=15,
        )
        result = response.json().get("timeseries", {}).get("result", [])
        lines: dict[str, list[float]] = {}
        for item in result:
            for key, entries in item.items():
                if key.startswith("annual") and isinstance(entries, list):
                    values = [n(entry.get("reportedValue", {}).get("raw")) for entry in entries]
                    lines[key] = [v for v in values if v is not None]
        return lines
    except (requests.RequestException, ValueError, TypeError):
        return {}


def latest(lines: dict[str, list[float]], key: str) -> float | None:
    values = lines.get(key, [])
    return values[-1] if values else None


def previous(lines: dict[str, list[float]], key: str) -> float | None:
    values = lines.get(key, [])
    return values[-2] if len(values) > 1 else None


def fetch_market_data(state: ResearchState) -> ResearchState:
    raw = state["ticker"].strip().upper()
    candidates = exchange_candidates(raw)
    chart: dict[str, Any] | None = None
    resolved_symbol: str | None = None
    for candidate in candidates:
        chart = yahoo_chart(candidate)
        if chart:
            resolved_symbol = candidate
            break
    if chart is None or resolved_symbol is None:
        raise ValueError("No recent market data was returned. Use an NSE symbol (RELIANCE, NSE:RELIANCE, or RELIANCE.NS) or BSE symbol (BSE:RELIANCE or RELIANCE.BO).")
    meta, lines = chart["meta"], yahoo_fundamentals(resolved_symbol)
    # Yahoo occasionally omits BSE statement lines. NSE fundamentals are the
    # same issuer-level filings for cross-listed Indian companies.
    if resolved_symbol.endswith(".BO") and any(latest(lines, k) is None for k in ("annualDilutedEPS", "annualStockholdersEquity", "annualDilutedAverageShares")):
        lines = yahoo_fundamentals(f"{resolved_symbol[:-3]}.NS") or lines
    price = chart["price"]
    eps = latest(lines, "annualDilutedEPS")
    equity = latest(lines, "annualStockholdersEquity")
    shares = latest(lines, "annualDilutedAverageShares")
    book = equity / shares if equity is not None and shares not in (None, 0) else None
    fair_value = math.sqrt(22.5 * eps * book) if eps and book and eps > 0 and book > 0 else None
    total_debt, cash = latest(lines, "annualTotalDebt"), latest(lines, "annualCashCashEquivalentsAndShortTermInvestments")
    ebit = latest(lines, "annualEBIT")
    invested_capital = (total_debt or 0) + (equity or 0) - (cash or 0)
    roce = ebit / invested_capital * 100 if ebit is not None and invested_capital > 0 else None
    revenue, revenue_prior = latest(lines, "annualTotalRevenue"), previous(lines, "annualTotalRevenue")
    opex, opex_prior = latest(lines, "annualOperatingExpense"), previous(lines, "annualOperatingExpense")
    net_income, interest = latest(lines, "annualNetIncome"), latest(lines, "annualInterestExpense")
    receivables, receivables_prior = latest(lines, "annualAccountsReceivable"), previous(lines, "annualAccountsReceivable")
    inventory, inventory_prior = latest(lines, "annualInventory"), previous(lines, "annualInventory")
    short_debt, ocf, capex = latest(lines, "annualCurrentDebt"), latest(lines, "annualOperatingCashFlow"), latest(lines, "annualCapitalExpenditure")
    dividends = latest(lines, "annualCashDividendsPaid")
    fcf = ocf + capex if ocf is not None and capex is not None else None
    gross_profit = latest(lines, "annualGrossProfit")
    current_assets, current_liabilities = latest(lines, "annualCurrentAssets"), latest(lines, "annualCurrentLiabilities")
    debt_equity = total_debt / equity if total_debt is not None and equity not in (None, 0) else None
    roe = net_income / equity * 100 if net_income is not None and equity not in (None, 0) else None
    liquidity_ratio = current_assets / current_liabilities if current_assets is not None and current_liabilities not in (None, 0) else None
    interest_coverage = ebit / abs(interest) if ebit is not None and interest not in (None, 0) else None

    facts = {
        "ticker": meta.get("symbol", resolved_symbol), "company": meta.get("longName") or meta.get("shortName") or resolved_symbol,
        "currency": meta.get("currency", "INR"), "price": ratio(price), "pe": ratio(price / eps if eps not in (None, 0) else None),
        "debt_equity": ratio(debt_equity), "price_book": ratio(price / book if book not in (None, 0) else None),
        "roe": ratio(roe), "gross_margin": ratio(gross_profit / revenue * 100 if gross_profit is not None and revenue not in (None, 0) else None),
        "eps": ratio(eps), "book_value": ratio(book), "fair_value": ratio(fair_value),
        "market_cap": None, "as_of": datetime.now(timezone.utc).strftime("%d %b %Y, %H:%M UTC"),
    }
    financials = {
        "revenue_change_pct": percent_change(revenue, revenue_prior), "opex_change_pct": percent_change(opex, opex_prior),
        "net_income": n(net_income), "interest_expense": n(interest), "total_debt": n(total_debt), "equity": n(equity),
        "receivable_change_pct": percent_change(receivables, receivables_prior), "inventory_change_pct": percent_change(inventory, inventory_prior),
        "short_term_debt": n(short_debt), "operating_cash_flow": n(ocf), "capex": n(capex), "free_cash_flow": n(fcf),
        "dividends_paid": n(dividends), "liquidity_ratio": ratio(liquidity_ratio), "industry_pe": None,
        "interest_coverage": ratio(interest_coverage), "raw_note": "Financial-statement figures are annual values reported by the market-data provider.",
    }
    return {**state, "ticker": facts["ticker"], "facts": facts, "financials": financials, "web_news": web_search_headlines(facts["ticker"], facts["company"])}


def generate_report(state: ResearchState) -> ResearchState:
    key = os.getenv("OPENAI_API_KEY", OPENAI_API_KEY)
    if not key or key == "PASTE_YOUR_OPENAI_API_KEY_HERE":
        return {**state, "ai_report": fallback_report(state)}
    schema = {"news": ["five brief, material developments/expert-view points"], "income_statement": ["six concise answers in stated order"], "balance_sheet": ["six concise answers in stated order"], "cash_flow": ["five concise answers in stated order"], "disclaimer": "short educational disclaimer"}
    prompt = f"""Use only these supplied facts. Return STRICT JSON matching this schema: {json.dumps(schema)}.
Company facts: {json.dumps(state['facts'])}
Financial statements: {json.dumps(state['financials'])}
Web-search headlines from the last six months (may be empty): {json.dumps(state['web_news'])}
For news, distinguish known headlines from absent data; do not invent events or analyst opinions. Use precise, plain language; each item under 30 words. All monetary financial-statement amounts must be written in Indian rupees crores (₹ Cr), never as raw rupees."""
    try:
        model = ChatOpenAI(model="gpt-4o-mini", api_key=key, temperature=0.2)
        response = model.invoke([SystemMessage(content="You are a conservative equity-research analyst."), HumanMessage(content=prompt)])
        content = re.sub(r"^```json\s*|\s*```$", "", response.content.strip())
        return {**state, "ai_report": json.loads(content)}
    except Exception:
        return {**state, "ai_report": fallback_report(state)}


def direction(label: str, change: float | None) -> str:
    return f"{label} {'increased' if change > 0 else 'decreased' if change < 0 else 'was broadly flat'} ({change:+.1f}% year-over-year)." if change is not None else f"{label} trend is unavailable from the reported statements."


def fallback_report(state: ResearchState) -> dict[str, Any]:
    f, x, heads = state["facts"], state["financials"], state["web_news"]
    news = heads[:5] or ["No recent web-news headlines were retrieved. Try again shortly for a source-grounded briefing."]
    return {
        "news": news + ["No additional verified expert consensus was available from the retrieved sources."] * max(0, 5-len(news)),
        "income_statement": [direction("Revenue", x["revenue_change_pct"]), direction("Operating expenses", x["opex_change_pct"]), f"Net income: {crore(x['net_income'])}.", "Unusual revenue requires note-level disclosures; not determined from summarized data.", "Earnings consistency requires multi-year review; no conclusion from this snapshot.", f"Interest expense: {crore(x['interest_expense'])}; assess against EBIT for coverage."],
        "balance_sheet": [f"Total debt: {crore(x['total_debt'])}; evaluate versus cash flow and equity.", f"Equity: {crore(x['equity'])}; {'negative' if (x['equity'] or 0) < 0 else 'not negative in this snapshot' }.", "Asset-quality trend needs impairment and ageing notes.", direction("Accounts receivable", x["receivable_change_pct"]), direction("Inventory", x["inventory_change_pct"]), f"Short-term debt: {crore(x['short_term_debt'])}."],
        "cash_flow": [f"Operating cash flow: {crore(x['operating_cash_flow'])}; {'negative' if (x['operating_cash_flow'] or 0) < 0 else 'not negative'}.", f"Capital expenditure: {crore(x['capex'])}; compare against operating cash flow.", "Compare net income with operating cash flow for a full cash-conversion assessment.", f"Free cash flow: {crore(x['free_cash_flow'])}; {'negative' if (x['free_cash_flow'] or 0) < 0 else 'not negative'}.", f"Dividends paid: {crore(x['dividends_paid'])}; check alongside free cash flow."],
        "disclaimer": "Educational research aid, not investment advice. Verify figures and filings before making investment decisions.",
    }


graph = StateGraph(ResearchState)
graph.add_node("market_data", fetch_market_data)
graph.add_node("analysis", generate_report)
graph.set_entry_point("market_data")
graph.add_edge("market_data", "analysis")
graph.add_edge("analysis", END)
research_graph = graph.compile()


@app.get("/")
def home():
    return FileResponse("static/index.html")


@app.post("/api/analyze")
def analyze(request: TickerRequest):
    try:
        result = research_graph.invoke({"ticker": request.ticker})
        return {"facts": result["facts"], "financials": result["financials"], "report": result["ai_report"], "source": "Web-news search and Yahoo Finance statement data"}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {exc}")
